# -*- coding: utf-8 -*-
from . import create_appointment_wizard
from . import appointment_report_wizard
from . import patient_report_wizard